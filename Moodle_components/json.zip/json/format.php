<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Missing word question importer.
 *
 * @package    qformat_missingword
 * @copyright  1999 onwards Martin Dougiamas {@link http://moodle.com}
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/question/type/automated_essay/questiontype.php');



/**
 * Missing word question importer.
 *
 * This Moodle class provides all functions necessary to import and export
 * one-correct-answer multiple choice questions in this format:
 *
 *    As soon as we begin to explore our body parts as infants
 *    we become students of {=anatomy and physiology ~reflexology
 *    ~science ~experiment}, and in a sense we remain students for life.
 *
 * Each answer is separated with a tilde ~, and the correct answer is
 * prefixed with an equals sign =
 *
 * Percentage weights can be included by following the tilde with the
 * desired percent.  Comments can be included for each choice by following
 * the comment with a hash mark ("#") and the comment.  Example:
 *
 *    This is {=the best answer#comment on the best answer ~75%a good
 *    answer#comment on the good answer ~a wrong one#comment on the bad answer}
 *
 * @copyright  1999 onwards Martin Dougiamas {@link http://moodle.com}
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class qformat_json extends qformat_default {

    public function provide_import() {
        return false;
    }

    public function provide_export() {
        return false;
    }

    /**
     * Return complete file within an array, one item per line
     * @param string filename name of file
     * @return mixed contents array or false on failure
     */
    protected function readdata($filename) {
        return "readdata";
    }

    public function readquestions($lines) {
        // Given an array of lines known to define a question in
        // this format, this function converts it into a question
        // object suitable for processing and insertion into Moodle.

        return $this->questions;
    }

    public function setQuestions($q) {

        foreach ( $q as $item )
        {
            $question = new qtype_automated_essay();

            $question->name = $item['questiontext'];
            $question->questiontext = $item['questiontext'];
            if ($item['thought1'] != ""){
                $question->score1 = $item['score1'];
            }
            if ($item['thought2'] != ""){
                $question->score2 = $item['score2'];
            }
            if ($item['thought3'] != ""){
                $question->score3 = $item['score3'];
            }
            if ($item['thought4'] != ""){
                $question->score4 = $item['score4'];
            }
            $question->thought1 = $item['thought1'];
            $question->thought2 = $item['thought2'];
            $question->thought3 = $item['thought3'];
            $question->thought4 = $item['thought4'];
            $question->responseformat = "editor";
            $question->qtype = "automated_essay";
            $question->questiontextformat = 1;
            $question->generalfeedback = "";
            $question->generalfeedbackformat = 1;
            $question->responserequired = 1;
            $question->responsefieldlines = 10;
            $question->attachments = 0;
            $question->attachmentsrequired = 0;
            $question->graderinfo = array('text' => '', 'format' => 1);
            $question->responsetemplate = array('text' => '', 'format' => 1);
            $question->maxbytes = 0;
            $question->length = 1;


            $this->questions[] = $question;

        }
    }


}


