<?php

namespace qbank_importquestions_withllm;

defined('MOODLE_INTERNAL') || die();

function getquestion($params) {
    global $DB;

    $sql = "
        SELECT q.id, q.name, qc.name as categoryname, qc.contextid, q.qtype
        FROM {question} q
        JOIN {question_versions} qv ON qv.questionid = q.id
        JOIN {question_bank_entries} qbe ON qbe.id = qv.questionbankentryid
        JOIN {question_categories} qc ON qc.id = qbe.questioncategoryid
        WHERE q.qtype = :qtype AND qc.contextid = :contextid
        ";

    $sql2 = "
        SELECT q.id, q.name, qc.name as categoryname, qc.contextid, q.qtype
        FROM {question} q
        JOIN (
            SELECT questionid, MAX(version) AS max_version
            FROM {question_versions}
            GROUP BY questionid
        ) qv_max ON q.id = qv_max.questionid
        JOIN {question_versions} qv ON qv.questionid = qv_max.questionid AND qv.version = qv_max.max_version
        JOIN {question_bank_entries} qbe ON qbe.id = qv.questionbankentryid
        JOIN {question_categories} qc ON qc.id = qbe.questioncategoryid
        WHERE q.qtype = :qtype AND qc.contextid = :contextid
        ";

    $sql3 = "
        SELECT 
        q.id, q.name, q.questiontext, qc.name as categoryname, qc.contextid, q.qtype, qae.thought1, qae.score1,
        qae.thought2, qae.score2, qae.thought3, qae.score3, qae.thought4, qae.score4
        FROM
        {question} q JOIN {question_versions} qv ON qv.questionid = q.id JOIN {question_bank_entries} qbe on qbe.id = qv.questionbankentryid 
        JOIN {question_categories} qc ON qc.id = qbe.questioncategoryid 
        LEFT JOIN {user} uc ON uc.id = q.createdby LEFT JOIN {user} um ON um.id = q.modifiedby left join {qtype_automated_essay_options} qae on q.id = qae.questionid
        WHERE q.parent = 0 
        AND qv.version = (SELECT MAX(v.version) FROM {question_versions} v JOIN {question_bank_entries} be ON be.id = v.questionbankentryid WHERE be.id = qbe.id)
	    AND (((qv.status = 'ready')) AND ((qbe.questioncategoryid = :qcategory)) AND ((q.qtype = :qtype)))
	    ORDER BY q.qtype ASC, q.name ASC
        ";

    return $DB->get_records_sql($sql3, $params);
}
