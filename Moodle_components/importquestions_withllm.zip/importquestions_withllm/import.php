<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Defines the import questions form.
 *
 * @package    qbank_importquestions
 * @copyright  1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


require_once(__DIR__ . '/../../../config.php');
require_once($CFG->dirroot . '/question/editlib.php');
require_once($CFG->dirroot . '/question/bank/importquestions_withllm/classes/form/import_form.php');
require_once($CFG->dirroot . '/question/format.php');
require_once($CFG->dirroot . '/question/renderer.php');
require_once($CFG->dirroot . '/question/bank/importquestions_withllm/classes/queries.php');

use qbank_importquestions_withllm\form\question_import_withllm_form;
use function qbank_importquestions_withllm\getquestion;

require_login();
core_question\local\bank\helper::require_plugin_enabled('qbank_importquestions_withllm');
list($thispageurl, $contexts, $cmid, $cm, $module, $pagevars) =
        question_edit_setup('import', '/question/bank/importquestions_withllm/import.php');

// Get display strings.
$txt = new stdClass();
$txt->importerror = get_string('importerror', 'qbank_importquestions_withllm');
$txt->importquestions = get_string('importquestions', 'qbank_importquestions_withllm');

list($catid, $catcontext) = explode(',', $pagevars['cat']);
if (!$category = $DB->get_record("question_categories", ['id' => $catid])) {
    throw new moodle_exception('nocategory', 'question');
}

$categorycontext = context::instance_by_id($category->contextid);
$category->context = $categorycontext;
// This page can be called without courseid or cmid in which case.
// We get the context from the category object.
if ($contexts === null) { // Need to get the course from the chosen category.
    $contexts = new core_question\local\bank\question_edit_contexts($categorycontext);
    $thiscontext = $contexts->lowest();
    if ($thiscontext->contextlevel == CONTEXT_COURSE) {
        require_login($thiscontext->instanceid, false);
    } else if ($thiscontext->contextlevel == CONTEXT_MODULE) {
        list($module, $cm) = get_module_from_cmid($thiscontext->instanceid);
        require_login($cm->course, false, $cm);
    }
    $contexts->require_one_edit_tab_cap($edittab);
}

$PAGE->set_url($thispageurl);

$importform = new question_import_withllm_form($thispageurl, ['contexts' => $contexts->having_one_edit_tab_cap('import'),
    'defaultcategory' => $pagevars['cat']]);

$params = [
        'qtype' => "automated_essay",
        'qcategory' => $catid
    ];

$results = getquestion($params);


if ($importform->is_cancelled()) {
    redirect($thispageurl);
}
// Page header.
$PAGE->set_title($txt->importquestions);
$PAGE->set_heading($COURSE->fullname);
$PAGE->activityheader->disable();

echo $OUTPUT->header();

// Print horizontal nav if needed.
$renderer = $PAGE->get_renderer('core_question', 'bank');

$qbankaction = new \core_question\output\qbank_action_menu($thispageurl);
echo $renderer->render($qbankaction);

// File upload form submitted.
if ($form = $importform->get_data()) {

    $selected = [];
    $i = 0;
    foreach ($results as $result) {
        $label = "question" . $i;
        if($form->$label == "1") {
            $question = array('questionname' => $result->name,
                              'questiontext' => $result->questiontext,
                              'thought1' => $result->thought1,
                              'score1' => $result->score1,
                              'thought2' => $result->thought2,
                              'score2' => $result->score2,
                              'thought3' => $result->thought3,
                              'score3' => $result->score3,
                              'thought4' => $result->thought4,
                              'score4' => $result->score4,
                               'qtype' => $result->qtype);

            $selected[] = $question;
        }
        $i++;
    }

    $course_id = $COURSE->id . '_' . $COURSE->shortname;

    $payload = array('model' => $COURSE->model, 'apikey' => $COURSE->apikey, 'courseid' => $course_id, 
        'prompt' => $form->prompt, 'questions' => $selected, 'xurl' => $COURSE->enableurls, 'xresources' => $COURSE->enablefiles, 'language' => $COURSE->lang);

    $url = "https://" . $COURSE->llm_ip . ":" . $COURSE->llm_port . "/generate_question";

    $options = array(
        'http' => array(
            'header'  => "Content-type: application/json\r\n",
            'method'  => 'POST',
            'content' => json_encode($payload)
        ),
        'ssl' => array(
            'verify_peer' => false,
            'verify_peer_name' => false
        )
    );

    $context  = stream_context_create($options);
    $result = file_get_contents($url, false, $context);

    $responseCode = null;
    if (isset($http_response_header)) {
        foreach ($http_response_header as $header) {
            if (preg_match('#HTTP/\d+\.\d+ (\d+)#', $header, $matches)) {
                $responseCode = intval($matches[1]);
                break;
            }
        }
    }

    $jsonString = null;

    if ($result === FALSE) {
        // Handle error
        switch ($responseCode) {
            case 401:
                throw new moodle_exception('invalid_api_key', 'LLM_server', '', 'Invalid API Key used. Response code: ' . $responseCode);
                break;
            case 500:
                throw new moodle_exception('server_side_error', 'LLM_server', '', 'Server side error code:' . $responseCode);
                break;
            default:
                echo "Unexpected response code from server: " . $responseCode;
                break;
        }
    } else {
        switch ($responseCode) {
            case 200:
                $jsonString = json_decode($result, true);
                break;
            default:
                echo "Unexpected response code: " . $responseCode;
                break;
        }
    }

    $formatfile = $CFG->dirroot . '/question/format/json/format.php';
    if (!is_readable($formatfile)) {
        throw new moodle_exception('formatnotfound', 'question', '', $form->format);
    }

    require_once($formatfile);

    $classname = 'qformat_json';
    $qformat = new $classname();

    // Load data into class.
    $qformat->setCategory($category);
    $qformat->setContexts($contexts->having_one_edit_tab_cap('import'));
    $qformat->setCourse($COURSE);
    $qformat->setFilename("autessay");
    $qformat->setRealfilename("autessay");
    $qformat->setMatchgrades($form->matchgrades);
    $qformat->setCatfromfile(!empty($form->catfromfile));
    $qformat->setContextfromfile(!empty($form->contextfromfile));
    $qformat->setStoponerror($form->stoponerror);
    $qformat->setQuestions($jsonString);

    // Do anything before that we need to.
    if (!$qformat->importpreprocess()) {
        throw new moodle_exception('cannotimport', '', $thispageurl->out());
    }

    // Process the uploaded file.
    if (!$qformat->importprocess()) {
        throw new moodle_exception('cannotimport', '', $thispageurl->out());
    }

    // In case anything needs to be done after.
    if (!$qformat->importpostprocess()) {
        throw new moodle_exception('cannotimport', '', $thispageurl->out());
    }

    // Log the import into this category.
    $eventparams = [
            'contextid' => $qformat->category->contextid,
            'other' => ['format' => 'qformat_json', 'categoryid' => $qformat->category->id],
    ];
    $event = \core\event\questions_imported::create($eventparams);
    $event->trigger();

    $params = $thispageurl->params() + ['category' => $qformat->category->id . ',' . $qformat->category->contextid];
    echo $OUTPUT->continue_button(new moodle_url('/question/edit.php', $params));
    echo $OUTPUT->footer();
    exit;
}

echo $OUTPUT->heading_with_help($txt->importquestions, 'importquestions', 'qbank_importquestions_withllm');

// Print upload form.
$importform->display();
echo $OUTPUT->footer();
