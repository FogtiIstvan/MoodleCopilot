<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'qtype_automated_essay', language 'en', branch 'MOODLE_20_STABLE'
 *
 * @package    qtype_automated_essay
 * @category    string
 * @copyright  1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

 defined('MOODLE_INTERNAL') || die();

 $string['pluginname'] = 'AutoEsszé';
 $string['pluginname_help'] = 'Esszé típusú kérdés, amelynek a javítása LLM-ek segítségével automatizált.';
 $string['pluginnameediting'] = 'Automatikusan javított esszé kérdés szerkesztése';
 $string['pluginnameadding'] = 'Automatikusan javított esszé kérdés hozzáadása';
 $string['pluginnamesummary'] = 'Az Esszé-hez hasonlóan nyitott szövegs válaszokat vár, azonban képes azok automatikus ';
 $string['criterias'] = 'Kritérium gondolatok';
 $string['nlines'] = '{$a} sor';
 $string['minwordlimit'] = 'Minimális szószám';
 $string['maxwordlimit'] = 'Maximális szószám';
 $string['responsefieldlines'] = 'Bemeneti mező mérete';
 $string['responseformat'] = 'Válasz formátuma';
 $string['responseoptions'] = 'Válasz opciók';
 $string['responserequired'] = 'Szöveg szükséges';
 $string['responsenotrequired'] = 'Szövegbevitel nem kötelező';
 $string['responseisrequired'] = 'Kötelező a diáknak szöveget megadnia';
 $string['responsetemplate'] = 'Válasz sablon';
 $string['responsetemplateheader'] = 'Válasz sablon';
 $string['responsetemplate_help'] = 'Bármely itt megadott szöveg megjelenik a válasz mezőben, amikor új próbálkozás indul a kérdésnél.';
 
 $string['critparam1'] = 'Gondolat';
 $string['critparam2'] = 'Pontszám';
 $string['crit'] = 'Kritérium';
 
 $string['examples'] = 'Példa értékelések';
 $string['example1'] = 'Példa 1';
 $string['example2'] = 'Példa 2';
 $string['answer'] = 'Értékelendő példa válasz';
 $string['evaluation'] = 'Példa értékelés';
 $string['score'] = 'Példa pontszám';
 
 $string['formateditor'] = 'HTML szerkesztő';
 $string['formateditorfilepicker'] = 'HTML szerkesztő fájlválasztóval';
 $string['formatmonospaced'] = 'Egyszerű szöveg, monospaced betűtípus';
 $string['formatnoinline'] = 'Nincs online szöveg';
 $string['formatplain'] = 'Egyszerű szöveg';
 
 $string['err_maxminmismatch'] = 'A maximális szószámnak nagyobbnak kell lennie a minimális szószámnál';
 $string['err_maxwordlimit'] = 'A maximális szószám engedélyezve van, de nincs beállítva';
 $string['err_maxwordlimitnegative'] = 'A maximális szószám nem lehet negatív szám';
 $string['err_minwordlimit'] = 'A minimális szószám engedélyezve van, de nincs beállítva';
 $string['err_minwordlimitnegative'] = 'A minimális szószám nem lehet negatív szám';

 $string['err_criterias'] = 'Legalább egy kritériumot meg kell adnia';
 
 //============================================================================================
 
 $string['acceptedfiletypes'] = 'Elfogadott fájltípusok';
 $string['acceptedfiletypes_help'] = 'Az elfogadott fájltípusokat korlátozhatja fájlkiterjesztések listájának megadásával. Ha a mezőt üresen hagyja, akkor minden fájltípus megengedett.';
 $string['allowattachments'] = 'Csatolmányok engedélyezése';
 $string['answerfiles'] = 'Válaszfájlok';
 $string['answertext'] = 'Válaszszöveg';
 $string['attachedfiles'] = 'Csatolmányok: {$a}';
 $string['attachmentsoptional'] = 'Csatolmányok opcionálisak';
 $string['attachmentsrequired'] = 'Csatolmányok szükségesek';
 $string['attachmentsrequired_help'] = 'Ez az opció megadja a minimális csatolmányok számát, amely szükséges ahhoz, hogy a válasz értékelhető legyen.';
 $string['graderinfo'] = 'Értékelők információi';
 $string['graderinfoheader'] = 'Értékelő információ';
 $string['maxbytes'] = 'Maximális fájlméret';
 $string['maxwordlimit_help'] = 'Ha a válaszhoz a diákoknak szöveget kell megadniuk, ez a maximális szavak száma, amelyet megadhatnak.';
 $string['maxwordlimitboundary'] = 'A kérdés szószáma {$a->limit} szó, és Ön {$a->count} szót próbál megadni. Kérjük, rövidítse le válaszát és próbálja újra.';
 $string['minwordlimit_help'] = 'Ha a válaszhoz a diákoknak szöveget kell megadniuk, ez a minimális szavak száma, amelyet meg kell adniuk.';
 $string['minwordlimitboundary'] = 'Ez a kérdés legalább {$a->limit} szó választ igényel, és Ön {$a->count} szót próbál megadni. Kérjük, bővítse válaszát és próbálja újra.';
 $string['mustattach'] = 'Amikor a "Nincs online szöveg" van kiválasztva, vagy a válaszok opcionálisak, legalább egy csatolmányt kell engedélyeznie.';
 $string['mustrequire'] = 'Amikor a "Nincs online szöveg" van kiválasztva, vagy a válaszok opcionálisak, legalább egy csatolmányt kell követelnie.';
 $string['mustrequirefewer'] = 'Nem követelhet több csatolmányt, mint amennyit megenged.';
 $string['nonexistentfiletypes'] = 'A következő fájltípusok nem voltak felismerhetők: {$a}';
 $string['pluginname_link'] = 'question/type/essay';
 $string['privacy:metadata'] = 'Az esszé kérdéstípus bővítmény lehetővé teszi a kérdésszerzőknek alapértelmezett beállítások megadását felhasználói preferenciákként.';
 $string['privacy:preference:defaultmark'] = 'Az alapértelmezett pontszám egy adott kérdéshez.';
 $string['privacy:preference:responseformat'] = 'Mi a válasz formátuma (HTML szerkesztő, egyszerű szöveg, stb.)?';
 $string['privacy:preference:responserequired'] = 'Kötelező-e a diáknak szöveget megadni, vagy a szövegbevitel opcionális.';
 $string['privacy:preference:responsefieldlines'] = 'A mező (textarea) méretét jelző sorok száma.';
 $string['privacy:preference:attachments'] = 'Engedélyezett csatolmányok száma.';
 $string['privacy:preference:attachmentsrequired'] = 'Kötelező csatolmányok száma.';
 $string['privacy:preference:maxbytes'] = 'Maximális fájlméret.';
 $string['wordcount'] = 'Szószám: {$a}';
 $string['wordcounttoofew'] = 'Szószám: {$a->count}, kevesebb, mint a szükséges {$a->limit} szó.';
 $string['wordcounttoomuch'] = 'Szószám: {$a->count}, több, mint a {$a->limit} szó korlát.';
 
 $string['nofeedback'] = 'Ehhez a kérdéshez nincs elérhető visszajelzés.';
 $string['openaiapikey'] = 'OpenAI API kulcs';
 $string['openaiapikeydesc'] = 'Adja meg itt az OpenAI API kulcsot.';
 
 $string['LLM_header'] = 'LLM beállítások';
 $string['course_options_enable_description'] = 'Válassza ki, mely erőforrások legyenek elérhetőek az LLM számára:';
 $string['course_options_Des'] = 'Kurzus leírása';
 $string['course_options_Url'] = 'URL-ek';
 $string['course_options_Res'] = 'Erőforrások (fájlok)';
 $string['course_options_add_apikey'] = 'Add meg az API kulcsot';
$string['course_options_choose_model'] = 'Válassz az elérhető modellek közül';
$string['course_options_add_ip'] = 'LLM szerver IP címe';
$string['course_options_add_port'] = 'portszám';

$string['yes'] = 'Igen';
$string['no'] = 'Nem';
$string['course_options_enablesurls'] = 'URL-ek engedélyezése';
$string['course_options_enablefiles'] = 'Erőforrásfájlok engedélyezése';
$string['course_options_enablesurls_help'] = 'Engedélyezés esetén az LLM felhasználja a kurzushoz tartozó URL-ek tartalmát a pontosabb segítségnyújtáshoz';
$string['course_options_enablefiles_help'] = 'Engedélyezés esetén az LLM felhasználja a kurzushoz tartozó erőforrásfájlok tartalmát a pontosabb segítségnyújtáshoz';
 
$string['err_examples'] = "Amennyiben minta javítást szeretnél hozzáadni, adj meg minden adatot!";
$string['err_thoughts'] = "Egy kritériumnak tartalmaznia kell egy gondolatot és egy pontszámot is!";

