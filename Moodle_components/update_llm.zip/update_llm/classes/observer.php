<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Event observer.
 *
 * @package    local_update_llm
 * @copyright  2014 Marina Glancy
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/moodlelib.php');

/**
 * Event observer.
 * Stores all actions about modules create/update/delete in plugin own's table.
 * This allows the block to avoid expensive queries to the log table.
 *
 * @package    local_update_llm
 * @copyright  2014 Marina Glancy
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class local_update_llm_observer {

    /** @var int indicates that course module was created */
    const CM_CREATED = 0;
    /** @var int indicates that course module was udpated */
    const CM_UPDATED = 1;
    /** @var int indicates that course module was deleted */
    const CM_DELETED = 2;

    /**
     * Store all actions about modules create/update/delete in own table.
     *
     * @param \core\event\base $event
     */
    public static function update(\core\event\base $event) {

        global $DB;
        global $COURSE;

        if($event->other['modulename'] != "url" && $event->other['modulename'] != "resource") {
            return;
        }

        $eventdata = new \stdClass();
        $payload = array();

        switch ($event->eventname) {
            case '\core\event\course_module_created':
                $eventdata->action = self::CM_CREATED;
                break;
            case '\core\event\course_module_updated':
                $eventdata->action = self::CM_UPDATED;
                break;
            case '\core\event\course_module_deleted':
                $eventdata->action = self::CM_DELETED;
                break;
            default:
                $eventdata->action = 555;
                break;
        }

        if ($event->other['modulename'] == "url" && $eventdata->action != self::CM_DELETED) {
            $oid = $event->other["instanceid"]; // or $urlid if you have the URL instance ID
            $url_record = $DB->get_record('url', array('id' => $oid), '*', MUST_EXIST);
            $payload["url"] = $url_record->externalurl;
            $payload["name"] = $url_record->name;
        }

        if ($event->other['modulename'] == "resource" && $eventdata->action != self::CM_DELETED) {
            $fs = get_file_storage();
            $files = $fs->get_area_files($event->contextid, 'mod_resource', 'content', 0, 'sortorder DESC, id ASC', false);        
            if (count($files) < 1) {
                $payload["filename"] = 'Error while loading file';
            } else {
                $file = reset($files);
                unset($files);
                $payload["filename"] = $file->get_filename();
                $payload["contents"] = base64_encode($file->get_content());
                $payload["mimetype"] = $file->get_mimetype();

                if($payload["mimetype"] != "application/pdf" && $payload["mimetype"] != "txt") {
                    throw new moodle_exception('file_type_exception', 'LLM_server', '', 'nvalid file format. LLM resource oberver can only handle PDF and TXT files.');

                }
            }
        } 

        $payload["courseid"] = $COURSE->id . '_' . $COURSE->shortname;
        $payload["activity"] = $event->other['modulename'];
        $payload["model"] = $COURSE->model;
        $payload["apikey"] = $COURSE->apikey;
        $payload["object_id"] = $event->objectid;
        $payload["language"] = $COURSE->lang;

        $payload["action"] = $eventdata->action;

        $url = "https://" . $COURSE->llm_ip . ":" . $COURSE->llm_port . "/update_module";

        $options = array(
            'http' => array(
                'header'  => "Content-type: application/json\r\n",
                'method'  => 'POST',
                'content' => json_encode($payload)
            ),
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false
            )
        );
    
        $context  = stream_context_create($options);
        $result = file_get_contents($url, false, $context);

        $responseCode = null;
        if (isset($http_response_header)) {
            echo "header is set";
            foreach ($http_response_header as $header) {
                if (preg_match('#HTTP/\d+\.\d+ (\d+)#', $header, $matches)) {
                    $responseCode = intval($matches[1]);
                    break;
                }
            }
        }

        echo "Response code: ";
        print_r($responseCode);

        if ($result === FALSE) {
            // Handle error
            switch ($responseCode) {
                case 401:
                    throw new moodle_exception('Authentication Error', 'LLM_server', '', 'Invalid API Key used. Response code: ' . $responseCode);
                    break;
                default:
                    throw new moodle_exception('server side error', 'LLM_server', '', 'Server side error code:' . $responseCode);
                    echo "Unexpected response code: " . $responseCode;
                    break;
            }
        }
    }


}